# Kairou para Android — projeto inicial

Este projeto abre https://kairou.space em uma janela de aplicativo Android (WebView).

## Importante
- Este ZIP contém o **código-fonte**, não um APK já compilado.
- O site precisa estar online e permitir abertura dentro de uma WebView.
- Não tenho acesso à hospedagem nem ao código-fonte do site, então não consigo instalar o app no seu celular nem garantir que todos os recursos do site funcionem.
- Para gerar o APK, o projeto precisa ser compilado em um ambiente Android/Gradle. O processo pode ser feito por um serviço de compilação na nuvem acessado pelo navegador Brave, mas será necessário enviar o projeto a esse serviço.

## Identificação
- Nome exibido: Kairou
- ID Android: `space.kairou.app`
- Versão: `1.0`
